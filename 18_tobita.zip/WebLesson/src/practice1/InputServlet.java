package practice1;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class InputServlet extends HttpServlet{
	protected void service(HttpServletRequest req, HttpServletResponse res)
	throws ServletException, IOException {

		req.setCharacterEncoding("UTF-8"); // 文字化け対策

		//sessionをonにして、英語と日本語をそれぞれ登録
		HttpSession session = req.getSession(true);
		String _eng = req.getParameter("english");
		String _jpn = req.getParameter("japanese");
		session.setAttribute("english", _eng);
		session.setAttribute("japanese", _jpn);

		List<Word> array = new ArrayList<>();
		WordDAO wdao = new WordDAO();

		Word wd = new Word(_eng, _jpn);
		array.add(wd);
		int count = wdao.registWords(array);

		List<Word> wList = new ArrayList<>();
		wList = wdao.getWords();

		// 入力数と保存数をsessionに登録
		session.setAttribute("inputNumber", count);
		session.setAttribute("saveNumber", wList.size());

		req.getRequestDispatcher("result.jsp").forward(req,res);
	}
}